CALCULATEUR DE LOT — PWA

Fichiers:
- index.html : application
- manifest.webmanifest : installation sur écran d'accueil
- sw.js : fonctionnement hors connexion

INSTALLATION:
1. Héberge ces fichiers sur un site HTTPS (GitHub Pages, Netlify, etc.).
2. Ouvre l'adresse avec Chrome sur Android.
3. Choisis "Installer" ou Chrome > ⋮ > "Ajouter à l'écran d'accueil".
4. Une fois installé, l'application peut fonctionner hors connexion.

IMPORTANT:
Les paramètres de lot/minimum/step doivent être vérifiés dans ton MT5/serveur Deriv avant utilisation.
